# TensorFlow Lite BERT QA iOS Example Example Application

This is an end-to-end example of BERT Question & Answer application.
